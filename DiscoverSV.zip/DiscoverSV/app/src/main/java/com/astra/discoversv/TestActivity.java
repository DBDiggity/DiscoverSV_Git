package com.astra.discoversv;


import android.content.res.Resources;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import com.astra.discoversv.Adapters.PicturesAdapter;
import com.astra.discoversv.Adapters.QuickHorizontalAdapter;
import com.astra.discoversv.Classes.GravitySnapHelper;
import com.astra.discoversv.Classes.PictureCard;
import com.astra.discoversv.Classes.QuickHorizontalCard;
import com.bumptech.glide.Glide;
import com.dingmouren.layoutmanagergroup.echelon.EchelonLayoutManager;
import com.dingmouren.layoutmanagergroup.skidright.SkidRightLayoutManager;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ClippingMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TestActivity extends AppCompatActivity {

    //    Views
    @BindView(R.id.recycler_view) RecyclerView recyclerView;
    @BindView(R.id.recycler_destination) RecyclerView destinationRV;
    @BindView(R.id.recycler_experience) RecyclerView experienceRV;
    @BindView(R.id.recycler_thingsToDo) RecyclerView ttd_Rv;
    @BindView(R.id.toolbar) Toolbar toolbar;
    @BindView(R.id.backdrop)
    ImageView backdrop;
    @BindView(R.id.appbar)
    AppBarLayout appBarLayout;
    @BindView(R.id.exo_player)
    PlayerView playerView;

    //    Variables
    private QuickHorizontalAdapter adapter;
    private List<QuickHorizontalCard> qhCards;
    private PicturesAdapter destinationAdapter, experienceAdapter, thingsToDoAdapter;
    private List<PictureCard> destinationCards, experienceCards, thingsToDoCards;

    SimpleExoPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        ButterKnife.bind(this);

        setSupportActionBar(toolbar);
        initCollapsingToolbar();
        initRecyclerView();
        initPlayer();
        prepareCards();

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null){
            player.release();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //TODO: Get current video time and restart from there when resumed
        initPlayer();
    }

    private void initPlayer(){
        player = ExoPlayerFactory.newSimpleInstance(this);
        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(this, Util.getUserAgent(this, "Discover SVG"));
//        Uri url = Uri.parse("http://www.tourism.gov.vc/tourism/images/mp3/abc.mp4");
        Uri url = Uri.parse("http://www.tourism.gov.vc/tourism/images/mp3/abc.mp4");
        MediaSource videoSource = new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(url);
        ClippingMediaSource clippingSource =
                new ClippingMediaSource(
                        videoSource,  /* startPositionUs= */ 12_000_000,
                        /* endPositionUs= */ 68_000_000);
        player.prepare(clippingSource);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
        playerView.setPlayer(player);
    }

    private void initHoriztonalRecycler(RecyclerView rView, @Nullable List<PictureCard> pCards, @Nullable PicturesAdapter phAdapter,
                                        @Nullable List<QuickHorizontalCard> qhCards, @Nullable QuickHorizontalAdapter qhAdapter){
        rView.setItemAnimator(new DefaultItemAnimator());
        rView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));

        if (pCards != null){
//            pCards = new ArrayList<>();
//            phAdapter = new PicturesAdapter(this, pCards);
            rView.setAdapter(phAdapter);
        } else if (qhCards != null) {
//            qhCards = new ArrayList<>();
//            qhAdapter = new QuickHorizontalAdapter(this, qhCards);
            rView.setAdapter(qhAdapter);
            SnapHelper snapHelper = new GravitySnapHelper(Gravity.START);
            snapHelper.attachToRecyclerView(rView);
        }
    }

    private void initRecyclerView(){



        qhCards = new ArrayList<>();
        adapter = new QuickHorizontalAdapter(this, qhCards);
//
        destinationCards = new ArrayList<>();
        destinationAdapter = new PicturesAdapter(this, destinationCards);
//
        experienceCards = new ArrayList<>();
        experienceAdapter = new PicturesAdapter(this, experienceCards);
//
        thingsToDoCards = new ArrayList<>();
        thingsToDoAdapter = new PicturesAdapter(this, thingsToDoCards);
//

        initHoriztonalRecycler(recyclerView, null, null, qhCards, adapter);
        initHoriztonalRecycler(destinationRV, destinationCards, destinationAdapter, null, null);
        initHoriztonalRecycler(experienceRV, experienceCards, experienceAdapter, null, null);
        initHoriztonalRecycler(ttd_Rv, thingsToDoCards, thingsToDoAdapter, null, null);

////        SkidRightLayoutManager mLayoutManager = new SkidRightLayoutManager((float) 1.5, (float) 0.5);
//        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
//        recyclerView.setLayoutManager(mLayoutManager);
//        recyclerView.setItemAnimator(new DefaultItemAnimator());
//        SnapHelper snapHelper = new GravitySnapHelper(Gravity.START);
//        snapHelper.attachToRecyclerView(recyclerView);
//        recyclerView.setAdapter(adapter);

//        RecyclerView.LayoutManager dLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
//        destinationRV.setLayoutManager(dLayoutManager);
//        destinationRV.setItemAnimator(new DefaultItemAnimator());
//        destinationRV.setAdapter(destinationAdapter);
//
//        RecyclerView.LayoutManager expLayouyManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
//        experienceRV.setLayoutManager(expLayouyManager);
//        experienceRV.setItemAnimator(new DefaultItemAnimator());
//        experienceRV.setAdapter(experienceAdapter);
//
//        RecyclerView.LayoutManager ttd_LayouyManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
//        ttd_Rv.setLayoutManager(ttd_LayouyManager);
//        ttd_Rv.setItemAnimator(new DefaultItemAnimator());
//        ttd_Rv.setAdapter(thingsToDoAdapter);
    }

    private void initCollapsingToolbar(){
        final CollapsingToolbarLayout collapsingToolbar = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        collapsingToolbar.setTitle(" ");
        appBarLayout.setExpanded(true);

        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = false;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                if (scrollRange + verticalOffset == 0) {
                    collapsingToolbar.setTitle(getString(R.string.app_name));
//                    collapsingToolbar.setTitle(" ");
                    isShow = true;
                } else if (isShow) {
                    collapsingToolbar.setTitle(" ");
                    isShow = false;
                }
            }
        });

        try {
            Glide.with(this).load(R.drawable.plane_islands).into(backdrop);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void prepareCards(){

        int[] pictures = new int[]{
                R.drawable.bridge_ocean,
                R.drawable.beach_birdseye,
                R.drawable.city_beach,

        };

        int[] destinationPics = new int[]{
                R.drawable.people_beach,
                R.drawable.night_beach,
                R.drawable.woman_boat,
                R.drawable.cloud_beach
        };

        int[] expPics = new int[]{
                R.drawable.chicken_rice,
                R.drawable.gardens_botanical,
                R.drawable.carnival_red,
                R.drawable.boat_beach
        };

        int[] ttd_Pics = new int[]{
                R.drawable.carnival_svg,
                R.drawable.tourist_beach,
                R.drawable.volcano_top,
                R.drawable.tourists_phone,
                R.drawable.bridge_ocean,
                R.drawable.stew_bowl
        };

        List<String> names = new ArrayList<>();
        names.add("Pier 86");
        names.add("Grant's Beach");
        names.add("Queenstown");

        List<String> destinationNames = new ArrayList<>();
        destinationNames.add("Villa Beach");
        destinationNames.add("Nighttime in the Grenadines");
        destinationNames.add("River 14");
        destinationNames.add("Young island");

        List<String> expNames = new ArrayList<>();
        expNames.add("Peleau");
        expNames.add("Historical Gardens");
        expNames.add("Cultural Festivals");
        expNames.add("Boat Rides");

        List<String > ttd_names = new ArrayList<>();
        ttd_names.add("Carnival");
        ttd_names.add("Explore");
        ttd_names.add("Hiking");
        ttd_names.add("Meet the locals");
        ttd_names.add("The View");
        ttd_names.add("Food");

        prepCards(names, pictures, adapter, null, qhCards, null );
        prepCards(destinationNames, destinationPics, null, destinationAdapter, null, destinationCards);
        prepCards(expNames, expPics, null, experienceAdapter, null, experienceCards);
        prepCards(ttd_names, ttd_Pics, null, thingsToDoAdapter, null, thingsToDoCards);
    }

        private void prepCards (List<String> names, int[] pics,@Nullable QuickHorizontalAdapter qha, @Nullable PicturesAdapter pa,
                                @Nullable List<QuickHorizontalCard> qhcList, @Nullable List<PictureCard> pcList) {
            if (qha != null) {
                for (int i = 0; i < names.size(); i++) {
                    QuickHorizontalCard qhc = new QuickHorizontalCard(pics[i], names.get(i));
                    qhcList.add(qhc);
                }

                qha.notifyDataSetChanged();
            } else if (pa != null){
                for (int i=0;i<names.size(); i++){
                   PictureCard pc = new PictureCard(names.get(i), pics[i]);
                    pcList.add(pc);
                }

                pa.notifyDataSetChanged();
            }
        }
    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view); // item position
            int column = position % spanCount; // item column

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount; // spacing - column * ((1f / spanCount) * spacing)
                outRect.right = (column + 1) * spacing / spanCount; // (column + 1) * ((1f / spanCount) * spacing)

                if (position < spanCount) { // top edge
                    outRect.top = spacing;
                }
                outRect.bottom = spacing; // item bottom
            } else {
                outRect.left = column * spacing / spanCount; // column * ((1f / spanCount) * spacing)
                outRect.right = spacing - (column + 1) * spacing / spanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
                if (position >= spanCount) {
                    outRect.top = spacing; // item top
                }
            }
        }
    }

    /**
     * Converting dp to pixel
     */
    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }



}
